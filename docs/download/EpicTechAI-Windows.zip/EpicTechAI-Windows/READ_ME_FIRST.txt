Epic Tech AI — Windows package
==============================

Put this WHOLE folder at:
  C:\Users\epict\EpicTechAI

Then:

  FIRST TIME:  double-click  1_FIRST_TIME_SETUP.bat
               (or just  2_RUN_EPIC.bat  if files are already here)

  EVERY TIME:  double-click  2_RUN_EPIC.bat
               or            START_EPIC.bat

You need OpenCode once:
  https://opencode.ai/docs
  then:  opencode providers

Site: https://epictechai.github.io/epic-tech-ai-agent/
