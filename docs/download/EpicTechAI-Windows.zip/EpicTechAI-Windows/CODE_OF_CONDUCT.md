# Contributor Covenant Code of Conduct

## Our pledge

We as members, contributors, and leaders pledge to make participation in the
Epic Tech AI community a harassment-free experience for everyone, regardless of
age, body size, visible or invisible disability, ethnicity, sex characteristics,
gender identity and expression, level of experience, education, socio-economic
status, nationality, personal appearance, race, caste, color, religion, or
sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our standards

Examples of behavior that contributes to a positive environment:

- Demonstrating empathy and kindness  
- Being respectful of differing opinions, viewpoints, and experiences  
- Giving and gracefully accepting constructive feedback  
- Accepting responsibility and apologizing to those affected by our mistakes  
- Focusing on what is best for the community  

Examples of unacceptable behavior:

- Sexualized language or imagery, and sexual attention or advances of any kind  
- Trolling, insulting or derogatory comments, and personal or political attacks  
- Public or private harassment  
- Publishing others’ private information without explicit permission  
- Other conduct which could reasonably be considered inappropriate  

## Enforcement responsibilities

Project maintainers are responsible for clarifying and enforcing standards and
may take appropriate corrective action in response to behavior they deem
inappropriate, threatening, offensive, or harmful.

## Scope

This Code of Conduct applies within all community spaces and when an individual
is officially representing the project in public spaces.

## Enforcement

Report incidents to **epictechai@gmail.com**. All complaints will be reviewed
and investigated promptly and fairly. Maintainers are obligated to respect the
privacy and security of the reporter.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org),
version 2.1.
